﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BotWars2.ClientBot.Messages
{
    public class GetMoveResponse
    {
        public Direction Direction { get; set; }
    }
}
