﻿namespace BotWars2.ClientBot.Messages
{
    public class ArenaState
    {
        public int ArenaHeight { get; set; }
        public int ArenaWidth { get; set; }
    }
}